'use strict';

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = ['count', 'avg', 'max', 'min', 'sum', 'std_deviation', 'variance', 'sum_of_squares', 'value_count', 'cardinality'];
module.exports = exports['default'];
